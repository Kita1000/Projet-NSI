screen_width = 1600
screen_height = 800
White = (255, 255, 255)
Black = (0, 0, 0)
Game_Title = "A Perilous Journey"
FPS = 60
speed = 1
moving_left = False
moving_right = False

# platform x position, y position, width, height
Platform_List = {(0, screen_height - 180, screen_width, 380),
                 (0, 400, 400, 50), (1200, 400, 400, 50)}
