import pygame as pyg
import pygame.sprite
from Settings import *


class Player(pyg.sprite.Sprite):
    def __init__(self, x, y, scale):
        pygame.sprite.Sprite.__init__(self)
        # player starting position
        player_Img = pygame.image.load('Playerimg.png')
        self.Scale_img = pygame.transform.scale(player_Img, (player_Img.get_width() * scale, player_Img.get_height() * scale))
        self.rect = self.Scale_img.get_rect()
        self.rect.center = (x, y)
        self.direction = pyg.math.Vector2(0, 0)


    def input(self):
        keys = pyg.key.get_pressed()
        if keys[pyg.K_RIGHT]:
            self.direction.x = 1
        if keys[pyg.K_LEFT]:
            self.direction.x = -1


        self.rect.x += self.direction.x



