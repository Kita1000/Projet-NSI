import pygame
import sys
from Sprites import *


# Setup pygame/window ---------------------------------------- #

def draw_text(text, font, color, surface, x, y):
    textobj = font.render(text, 1, color)
    textrect = textobj.get_rect()
    textrect.topleft = (x, y)
    surface.blit(textobj, textrect)


class Game:
    def __init__(self):
        pygame.init()
        self.mainClock = pygame.time.Clock()
        pygame.display.set_caption('A Perilous Journey')
        self.screen = pygame.display.set_mode((screen_width, screen_height), 0, 32)
        self.Main_background = pygame.image.load("Main_BG.jpg")

        self.Main_font = pygame.font.Font("Main_Font.otf", 95)
        self.Button_font = pygame.font.Font("Nicefont.ttf", 55)

    click = False

    def main_menu(self):
        while True:
            self.screen.blit(self.Main_background, (0, 0))

            draw_text('A Perilous Journey', self.Main_font, (20, 85, 22), self.screen, screen_width / 2.87,
                      screen_height / 2.65)

            mx, my = pygame.mouse.get_pos()

            button_1 = pygame.Rect(screen_width / 2.4, screen_height / 1.78, 250, 50)
            button_2 = pygame.Rect(screen_width / 2.4, screen_height / 1.75 + 75, 250, 50)
            button_3 = pygame.Rect(screen_width / 2.4, screen_height / 1.75 + 150, 250, 50)

            if button_1.collidepoint((mx, my)):
                if click:
                    self.new_game()
            if button_2.collidepoint((mx, my)):
                if click:
                    self.options()
            if button_3.collidepoint((mx, my)):
                if click:
                    pygame.quit()
                    sys.exit()
            pygame.draw.rect(self.screen, (107, 66, 37), button_1)
            draw_text("Play Game", self.Button_font, (255, 255, 255), self.screen, screen_width / 2.25,
                      screen_height / 1.75)
            pygame.draw.rect(self.screen, (107, 66, 37), button_2)
            draw_text("Options", self.Button_font, (255, 255, 255), self.screen, screen_width / 2.25,
                      screen_height / 1.5)
            pygame.draw.rect(self.screen, (107, 66, 37), button_3)
            draw_text("Quit Game", self.Button_font, (255, 255, 255), self.screen, screen_width / 2.25,
                      screen_height / 1.3)

            click = False
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        click = True

            pygame.display.update()
            self.mainClock.tick(FPS)

    def new_game(self):

        # Player introduction need to add fade, only pops up at every new game.
        self.screen.fill((0, 0, 0))
        draw_text("Where am I ?", self.Main_font, (255, 255, 255), self.screen, screen_width / 2.75,
                  screen_height / 2)
        pygame.display.flip()
        pygame.time.delay(3 * 100)
        self.screen.fill((0, 0, 0))
        draw_text("What is this place?", self.Main_font, (255, 255, 255), self.screen, screen_width / 2.75,
                  screen_height / 2)
        pygame.display.flip()
        pygame.time.delay(3 * 100)
        vel = 2
        isJump = False
        JumpCount = 9
        left = False
        right = False
        WalkCount = 0

        running = True
        while running:
            self.screen.blit(self.Main_background, (0, 0))
            Playerstart = Player(800, 600 ,0.18)
            self.screen.blit(Playerstart.Scale_img, Playerstart.rect)

            x = 500
            y = 500
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False

                keys = pygame.key.get_pressed()

                if keys[pygame.K_LEFT] and x > vel:
                    x -= vel
                if keys[pygame.K_RIGHT] and x < screen_width - 50 - vel:
                    x += vel
                if not (isJump):
                    if keys[pygame.K_SPACE]:
                        isJump = True
                else:
                    if JumpCount >= -9:
                        neg = 1
                        if JumpCount < 0:
                            neg = -1
                        y -= (JumpCount ** 2) * 0.5 * neg
                        JumpCount -= 1
                    else:
                        isJump = False
                        JumpCount = 9

            pygame.display.update()
            self.mainClock.tick(FPS)

    def options(self):
        running = True
        while running:
            self.screen.fill((0, 0, 0))

            draw_text('Options', self.Button_font, (255, 255, 255), self.screen, 20, 20)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False

            pygame.display.update()
            self.mainClock.tick(FPS)


G = Game()
G.main_menu()
